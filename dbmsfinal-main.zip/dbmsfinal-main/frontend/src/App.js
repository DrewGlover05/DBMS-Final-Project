import "./App.css";
import { HomePage, LoginPage } from "./pages";
import { useState, useEffect } from "react";

function App() {
  const [currentPage, setCurrentPage] = useState("login");

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      // validate token?
      setCurrentPage("HomePage");
    } else {
      setCurrentPage("LoginPage");
    }
  }, []);

  const renderPage = () => {
    switch (currentPage) {
      case "LoginPage":
        return <LoginPage setCurrentPage={setCurrentPage} />;
      case "HomePage":
        return <HomePage setCurrentPage={setCurrentPage} />;
      default:
        return <LoginPage setCurrentPage={setCurrentPage} />;
    }
  };

  return <div className="App">{renderPage()}</div>;
}

export default App;
