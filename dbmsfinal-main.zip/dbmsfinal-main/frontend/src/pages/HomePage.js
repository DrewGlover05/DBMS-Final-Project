function HomePage() {
  return (
    <>
      <h1>DataDoption!</h1>
    </>
  );
}

export default HomePage;
