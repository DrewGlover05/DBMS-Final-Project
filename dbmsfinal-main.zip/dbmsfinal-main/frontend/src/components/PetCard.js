function PetCard() {
  return <></>;
}

export default PetCard;
